package com.luojilab.component.componentlib.applicationlike;

/**
 * Created by mrzhang on 2017/6/15.
 */

public interface IApplicationLike {

    void onCreate();

    void onStop();
}
