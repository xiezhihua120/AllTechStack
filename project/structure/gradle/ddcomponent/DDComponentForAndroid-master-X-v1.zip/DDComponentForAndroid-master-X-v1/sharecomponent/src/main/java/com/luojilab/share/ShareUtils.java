package com.luojilab.share;

import android.content.Context;
import android.util.Log;

import com.luojilab.component.basiclib.ToastManager;

public class ShareUtils {

    public static void test(Context context) {
        Log.d("xiezhihua", "ShareUtils.test()");
        Log.e("xiezhihua", "ShareUtils.test()");

        ToastManager.show(context, "大家好");
    }

}
