package com.luojilab.share.runalone.application;

import com.luojilab.component.basiclib.ToastManager;
import com.luojilab.component.basicres.BaseApplication;
import com.luojilab.share.ShareUtils;

/**
 * Created by mrzhang on 2017/8/16.
 */

public class ShareApplication extends BaseApplication {

    @Override
    public void onCreate() {
        super.onCreate();

        ShareUtils.test(this);

    }

}