package com.luojilab.componentservice.share.bean;

/**
 * Created by mrzhang on 2017/12/14.
 */

public class Author {
    private String name;
    private int age;
    private String county;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }
}
