package com.luojilab.componentservice.readerbook;

import android.support.v4.app.Fragment;

/**
 * export module services
 * Created by mrzhang on 2017/6/15.
 */

public interface ReadBookService {

    Fragment getReadBookFragment();
}
