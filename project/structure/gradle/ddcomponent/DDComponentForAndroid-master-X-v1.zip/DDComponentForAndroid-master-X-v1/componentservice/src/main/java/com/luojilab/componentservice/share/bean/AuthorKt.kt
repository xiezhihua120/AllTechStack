package com.luojilab.componentservice.share.bean

/**
 * Created by mrzhang on 2018/2/26.
 */
data class AuthorKt(var name: String, var age: Int, var county: String)