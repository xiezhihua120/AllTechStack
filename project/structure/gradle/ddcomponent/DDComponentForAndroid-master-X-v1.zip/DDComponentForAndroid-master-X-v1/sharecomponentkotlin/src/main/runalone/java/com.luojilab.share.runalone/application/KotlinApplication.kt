package com.luojilab.share.runalone.application

import com.luojilab.component.basicres.BaseApplication

/**
 * Created by mrzhang on 2018/1/5.
 */
class KotlinApplication : BaseApplication() {

    override fun onCreate() {
        super.onCreate()
    }

}